<?php
include_once 'auth.php';
include_once('inc/utility_sms1.php');

		   $getdata ='SELECT * FROM flow_data_2445  WHERE run_id = '.$RUN_ID;
		   $getdata_source = exequery(TD::conn(),$getdata);
			
		
		   $shenqing_ID = date('YmdHis').$RUN_ID;

	while($getdata_arr = mysql_fetch_array($getdata_source)){

$f2r = array(
			  'create_man'=>$getdata_arr['begin_user'],              //������uid
			  'create_man_text'=>$getdata_arr['data_30'],             //�������
			  'create_time'=>$getdata_arr['begin_time'],             //����ʱ��
			  'update_man'=>$getdata_arr['begin_user'],              //������uid
			  'update_man_text'=>$getdata_arr['data_30'],              //����������
			  'update_time'=>$getdata_arr['begin_time'],              //����ʱ��
			  
			  'deleted'=>'0',          //�Ƿ�ɾ��
					 
			  'field2'=>$getdata_arr['data_30'],        //  ������
			  'field3'=>$getdata_arr['data_31'],        //  ��������
			  'field4'=>$getdata_arr['data_32'],        //  ������λ
			  'field5'=>$getdata_arr['data_33'],        //  ��������
			 );
			 
			  $create_time = strtotime($f2r['create_time']);

			$get_son_list_1 = 'SELECT * FROM flow_data_2445_list_35 WHERE run_id = '.$RUN_ID;	
			$get_son_list_1_s = exequery(TD::conn(),$get_son_list_1);
			
	while($son_1_arr = mysql_fetch_array($get_son_list_1_s)){
		if(empty($son_1_arr[4])){
			continue;
		}
			$shenqing_ID2 = $shenqing_ID.$son_1_arr[0];
						
$f3r = array(
              'field1'=>$shenqing_ID2,                      //  ��Ʒ���  
              'field6'=>$son_1_arr[4],                      //  ��Ʒ����
              'field7'=>$son_1_arr[5],                      //  Ʒ��
              'field8'=>$son_1_arr[6],                      //  �ͺ�   
				//���			  
              'field9'=>$son_1_arr[8],                      //  ��λ
              'field10'=>$son_1_arr[9],                      //  ����
			   //  �ο��۸�
              'field11'=>$son_1_arr[11],                      //  ���� 
              'field12'=>$son_1_arr[12],                      //  С��
              'field13'=>$son_1_arr[13],                      //  ��ע	 
			);
			
			 $f3r['field11'] = number_format($f3r['field11'],2);
			 $f3r['field12'] = number_format($f3r['field12'],2);

$insercrm = "INSERT INTO crm_module_15(create_man, create_man_text, create_time, deleted, field1, field2, field3, field4, field5,  field6,  field7, field8, field9, field10, field11, field12, field13) VALUES";

$insercrm2 = "('".$f2r['create_man']."', '".$f2r['create_man_text']."','".$create_time."', '".$f2r['deleted']."','".$f3r['field1']."','".$f2r['field2']."', '".$f2r['field3']."','".$f2r['field4']."','".$f2r['field5']."','".$f3r['field6']."','".$f3r['field7']."','".$f3r['field8']."','".$f3r['field9']."','".$f3r['field10']."','".$f3r['field11']."','".$f3r['field12']."','".$f3r['field13']."')";

$insercrm_source = exequery(TD::conn(),$insercrm.$insercrm2.';'); 
				
	}		
/*
if(!$insercrm_source){
	           $send_time = time(); //����ʱ�䣬��ǰʱ��
			   $content ='���������ˮ��Ϊ'.$getdata_arr['run_id'].'������д��CRM<>ʧ��,���ֶ�¼��.' ;
               send_sms($send_time,$getdata_arr['begin_user'],$getdata_arr['begin_user'],'0',$content,'');
		}else{
		
			   $up ='UPDATE flow_data_132 SET data_221 = 1 WHERE RUN_ID = \''.$RUN_ID.'\'';
		       $source = exequery(TD::conn(),$up);
	   }
*/	   
		
	}
	
/*	
$TASK_ID='31';
update_office_task($TASK_ID, '1', date('Y-m-d H:i:s', time()));
echo '+OK';
*/

?>