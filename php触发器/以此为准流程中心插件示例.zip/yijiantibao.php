<?php
	 include_once("inc/auth.inc.php");
	 session_start();
	 include_once("inc/flow_engine2.0/inc/engine/TFlowEngine.php");
     
	 //��ȡ������������
	 $runData = \engine\TFlowEngine::getRunData($FLOW_ID,$RUN_ID);
	 $link = "<a target=\'_blank\' href=\'/general/approve_center/list/print/index.php?actionType=view&MENU_FLAG=&RUN_ID={$RUN_ID}&PRCS_KEY_ID=&FLOW_ID={$FLOW_ID}\'>{$RUN_ID}</a>";
	 $array=array(
					'create_man'		=>$runData['begin_user'],
					'create_man_text' 	=>$runData['data_m22342'],
					'create_time' 		=>time(),
					'update_man' 		=>$runData['begin_user'],
					'update_man_text' 	=>$runData['data_m22342'],
					'update_time' 		=>time(),
					'owner' 			=>$runData['begin_user'],
					'owner_dept' 		=>$runData['data_m22352'],
					'create_dept' 		=>$runData['data_m22352'],
					'create_dept_text' 	=>$runData['data_m22344'],
					'deleted' 			=>0,
					
					'field1' 			=>$runData['data_m22346'],//�᰸���� 
                    'field2' 			=>$runData['data_m22345'],//�������� 					
					'field3' 			=>$runData['data_m22343'],//�걨ʱ�� 
					'field4' 			=>$runData['data_m22352'],//��������
					'field4_text' 		=>$runData['data_m22344'],//��������					
					'field5' 			=>$runData['data_m22349'],//������	 
					'field6' 			=>$runData['data_m22348'],//����״̬
					'field7' 			=>$runData['data_m22347'],//��Ҫ����
					'field8' 			=>$link				//link

	);
	
	//���ڸ�ʽ����ת��
	$array['data_m22343'] = strtotime($array['data_m22343']);
	//ת��
	$array['data_m22347'] = addslashes($array['data_m22347']);
	
	//��ϲ���sql
	
	$keyStr = '';
	$valStr = '';
	foreach($array as $key =>$val){
		$keyStr .=$key.',';
		$valStr .="'{$val}',";
	}
	$keyStr = substr($keyStr,0,-1);
	$valStr = substr($valStr,0,-1);
	
	$insert = "insert into CRM_MODULE_5({$keyStr})values({$valStr})";
	$source = exequery(TD::conn(),$insert);
	
?>